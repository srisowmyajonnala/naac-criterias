import React from "react";
import "./index.css";

const C3 = () => {
  return (
    <div class="container_2">
      <div class="heading-container">
        <p class="heading-1">
          <span class="span-style">1.3</span> &nbsp; Curriculum Enrichment
        </p>
      </div>

      <div class="margin-container">
        <p class="heading-2">
          {" "}
          <b>
            {" "}
            1.3.1: The Instition integrates cross cutting issues relevant to Professional Ethics, gender , human values into the curriculum{" "}
          </b>
          <button class="btn help">Help</button>{" "}
        </p>
        <textarea cols="40" rows="10" class="txtbox"></textarea>
        <hr></hr>
        <table class="adjustment-9">
          <tr class="color-1">
            <th> File Description</th>
            <th> Template </th>
            <th> Documents </th>
          </tr>
          <tr>
            <td>Upload the list and description of the courses which address the Professional ethics, gender , equality and sustainability into the curriculum.</td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
          <tr>
            <td>Any additional information </td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
        </table>
      </div>

      <div class = "margin5-cointainer">
      <div class=" new">
          <label for="one" class="heading-3">
            {" "}
            <b>
              {" "}
              1.3.2: Average percentage of courses that include experimental learning through project work/field work/internship during last five years.
            </b>{" "}
          </label>
          <input id="one" class="size" type=" text" />{" "}
        </div>
        <hr></hr>
        <div class="adjustment-7">
          <label for="one">
            <b>
             1.3.2.1:Number of courses that include experimental learning through project work/field work/internship during last five years.{" "}
            </b>{" "}
          </label>
          <table class="table2">
            <tr>
              <th>2018-19</th>
              <th>2017-18</th>
              <th>2016-17</th>
              <th>2015-16</th>
              <th>2014-15</th>
            </tr>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
          </table>
        </div>
        <hr></hr>
        <div class="adjustment-8">
          <label for="one" class="heading13">
            <b>Related Input</b>
            <br></br>Number of courses offered by the institution across all teh programs during last five years
          </label>
          <table class="table-2" border="1px" solid black>
            <tr>
              <th>Year1</th>
              <th>Year2</th>
              <th>Year3</th>
              <th>Year4</th>
              <th>Year5</th>
            </tr>
            <td>500</td>
            <td>341</td>
            <td>339</td>
            <td>347</td>
            <td>336</td>
          </table>
         <hr></hr>
         <p>Total academic year considered: 5</p>
        </div>
        <hr></hr>
        <hr></hr>
        <table class="adjustment-9">
          <tr class="color-1">
            <th> File Description</th>
            <th> Template </th>
            <th> Documents </th>
          </tr>
          <tr>
            <td>
            Program/ curriculum syllabus of the courses
            </td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
          <tr>
            <td>
              MoU's with relevant organization of this courses. {" "}
              <span class="red-star">★</span>
            </td>
            <td>
              <a href="url">Data Template </a>
            </td>

            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
          <tr>
            <td>
             Minutes of board of studies/academic council greetings with approval of these courses
            </td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
          <tr>
            <td>
             Any additional information
            </td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>

          
        </table>
      </div>

      <div class = "margin5-cointainer">
      <div class=" new">
          <label for="one" class="heading-3">
            {" "}
            <b>
              {" "}
              1.3.3: Percentage of students undertaking field work/project work /internships (Data for the latest completed academic year)
            </b>{" "}
          </label>
          <input id="one" class="size" type=" text" />{" "}
        </div>
        <hr></hr>
        <div class="adjustment-7">
          <label for="one">
            <b>
             1.3.3.1:Number of courses that include experimental learning through project work/field work/internship during last five years.{" "}
            </b>{" "}
          </label>
          <input id="one" class="size" type=" text" />{" "}
        </div>
        <hr></hr>
        <div class="adjustment-8">
          <label for="one" class="heading13">
            <b>Related Input</b>
            <br></br>Number of students year-wise during last five years
          </label>
          <table class="table-2" border="1px" solid black>
            <tr>
              <th>Year1</th>
              <th>Year2</th>
              <th>Year3</th>
              <th>Year4</th>
              <th>Year5</th>
            </tr>
            <td>1006</td>
            <td>1337</td>
            <td>1694</td>
            <td>1893</td>
            <td>1697</td>
          </table>
        
        
        </div>
        <hr></hr>
        <hr></hr>
        <table class="adjustment-9">
          <tr class="color-1">
            <th> File Description</th>
            <th> Template </th>
            <th> Documents </th>
          </tr>
          <tr>
            <td>
              List of programmes and number of students undertaking project work/field work/internships. {" "}
              <span class="red-star">★</span>
            </td>
            <td>
              <a href="url">Data Template </a>
            </td>

            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
          
          <tr>
            <td>
             Any additional information
            </td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>

          
        </table>
      </div>
    </div>
  );
};

export default C3;
