
import './App.css';
import C31 from "./Components/Criteria31"
import C32 from "./Components/Criteria32"
import C33 from "./Components/Criteria33"
import C34 from "./Components/Criteria34"
import C35 from './Components/Criteria35';



const App=()=> 
<>
    <C31/>
    <C32/>
    <C33/>
    <C34/>
    <C35/>
    <div class="button-flex-container">
        <button class="save-button-style">Save</button>
    </div>
    
</>

export default App;
