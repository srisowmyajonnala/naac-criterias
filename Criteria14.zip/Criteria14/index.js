import React from "react";
import "./index.css";

const C4 = () => {
  return (
    <div class="container7">
      <div class="heading-container">
        <p class="heading-1">
          <span class="span-style">1.4</span> &nbsp; Feedback System </p>
      </div>
      <div class="margin8-container">
        <div class="flex-1">
        
          <p>
            {" "}
            <b>
              {" "}
              1.4.1: <i>Institution obtain feedback on the syllabus and its transaction at  the institution from following stakeholders 1) Students 2) Teachers 3) Employers 4) Alumni </i>
              {" "}
            </b>
          </p>
          <div>
            <table class = "table-3">
             <tr><td><input
              type="radio"
              id="allof the above"
              name="fav_language"
              value="A.All of the above"
            />
              <label for="A.all of the above">A.All of the above</label>
            <input type="radio" id="html" name="fav_language" value="HTML" /> {" "}
            <label for="html">B.Any 3 of the above</label></td> </tr>
           <tr> <td> <input type="radio" id="html" name="fav_language" value="HTML" /> {" "}
            <label for="html">C.Any 2 of the above</label>{" "} 
          
            {" "}
            <input type="radio" id="html" name="fav_language" value="HTML" /> {" "}
            <label for="html">D.Any 1 of the above</label></td> </tr>
            <tr><td><input type="radio" id="html" name="fav_language" value="HTML" />
            <label for="html">E.None of the above</label> </td></tr>
            </table>
          </div>
          
        </div>

        <table class="adjustment-9">
          <tr class="color-1">
            <th> File Description</th>
            <th> Template </th>
            <th> Documents </th>
          </tr>
          <tr>
            <td>
             URL for stakeholder feedback report
             
            </td>
            <td>
            
            </td>
            <td>
            <input type="text" />
            </td>
          </tr>
          <tr>
            <td>
             Any additional information (Upload)
            </td>
            <td> </td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>

          <tr>
            <td>Action taken report of the institution on the feedback report as stated in the Minutes of the governing council syndicate,Board of Management (Upload)</td>
            <td> </td>

            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
        </table>
      </div>
      <div class="margin9-container">
        <div class="flex-1">
          <p>
            {" "}
            <b>
              {" "}
              1.4.2: Feedback Process of the institution may be classified as follows. Options<ul class="no-bullets">
                <li> 1.Feedback collected analyzed and action taken and feedback available on website</li> <li>2.Feedback collected analyzed and action has been taken</li>{" "}
                <li> 3.Feedback collected and analyzed</li>{" "}
                <li> 4.Feedback collected </li>{" "}
                <li> 5.Feedback not collected </li>{" "}
              </ul>{" "}
              {" "}
            </b>
          </p>
          <div class = "flex-4">
            <table class = "table-3">
              <tr>
            <td> <input
              type="radio"
              id="allof the above"
              name="fav_language"
              value="A.All of the above"
            />
              <label for="A.all of the above">A.All of the above</label></td></tr>
           <tr><td> <input type="radio" id="html" name="fav_language" value="HTML" /> {" "}
            <label for="html">B.Any 3 of the above</label></td></tr>
            <tr><td><input type="radio" id="html" name="fav_language" value="HTML" /> {" "}
            <label for="html">C.Any 2 of the above</label>{" "}</td></tr>
          
            {" "}
            <tr><td> <input type="radio" id="html" name="fav_language" value="HTML" /> {" "}
            <label for="html">D.Any 1 of the above</label></td></tr>
            <tr><td><input type="radio" id="html" name="fav_language" value="HTML" />
            <label for="html">E.None of the above</label></td></tr>
            </table>
          </div>
        </div>

        <table class="adjustment-9">
          <tr class="color-1">
            <th> File Description</th>
            <th> Template </th>
            <th> Documents </th>
          </tr>
          <tr>
            <td>
             URL for  feedback report
             
            </td>
            <td>
            
            </td>
            <td>
            <input type="text" />
            </td>
          </tr>
          <tr>
            <td>
            Upload Any additional information 
            </td>
            <td> </td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>

          
        </table>
      </div>
    </div>
  )
};

export default C4;