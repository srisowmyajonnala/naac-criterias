import React from "react";
import "./index.css";

const C2 = () => {
  return (
    <div class="container_1">
      <div class="heading-container">
        <p class="heading-1">
          <span class="span-style">1.2</span> &nbsp; Academic Flexibility
        </p>
      </div>
      <div class="margin4-container">
        <p class="heading-2"></p>

        <div class=" new">
          <label for="one" class="heading-3">
            {" "}
            <b>
              1.2.1:Percentage of Programmers in which choice Based Credit
              System (CBCS) elective course System has been implemented{" "}
            </b>{" "}
          </label>
          <input id="one" class="size" type=" text" />{" "}
        </div>
        <div class="adjustment-7">
          <label for="one" class=" heading-3">
            {" "}
            <b>
              1.2.1.1: Number of programmer in which CBCS Elective course system
              implemented.
            </b>
          </label>
          <input id="one" class="size-1" type="20" />
        </div>

        <hr></hr>
        <div class="adjustment-8">
          <label for="one" class="heading13">
            <b>Related Input</b>
            <br></br>Number of programs offered year wise for last fiver year?
          </label>
          <table class="table-2" border="1px" solid black>
            <tr>
              <th>Year1</th>
              <th>Year2</th>
              <th>Year3</th>
              <th>Year4</th>
              <th>Year5</th>
            </tr>
            <td>7</td>
            <td>7</td>
            <td>8</td>
            <td>8</td>
            <td>8</td>
          </table>
        </div>
        <table class="adjustment-9">
          <tr class="color-1">
            <th> File Description</th>
            <th> Template </th>
            <th> Documents </th>
          </tr>
          <tr>
            <td>Minutes of revalant Academic Council BOS meeting</td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
          <tr>
            <td>
              Institutional data in prescribed format{" "}
              <span class="red-star">★</span>
            </td>
            <td>
              <a href="url">Data Template </a>
            </td>

            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>

          <tr>
            <td>Any additional information</td>
            <td> </td>

            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
        </table>
      </div>

      <hr></hr>
      <div class="margin2-container">
        <div class=" new">
          <label for="one" class="heading-3">
            {" "}
            <b>
              {" "}
              1.2.2: Number of Add on /Certificates programs offered during the
              last five years
            </b>{" "}
          </label>
          <input id="one" class="size" type=" text" />{" "}
        </div>
        <hr></hr>
        <div class="adjustment-7">
          <label for="one">
            <b>
              1.2.2.1: How many Add on /Certificate programs are added within
              the last 5 years{" "}
            </b>{" "}
          </label>
          <table class="table2">
            <tr>
              <th>2018-19</th>
              <th>2017-18</th>
              <th>2016-17</th>
              <th>2015-16</th>
              <th>2014-15</th>
            </tr>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
          </table>
        </div>
        <hr></hr>
        <hr></hr>
        <table class="adjustment-9">
          <tr class="color-1">
            <th> File Description</th>
            <th> Template </th>
            <th> Documents </th>
          </tr>
          <tr>
            <td>
              List to Add/on Certificate Programs{" "}
              <span class="red-star">★</span>
            </td>
            <td>
              <a href="url">Data Template </a>
            </td>

            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
          <tr>
            <td>
              Broucher or any other documents related to add/on certificates
            </td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>

          <tr>
            <td>Any additional information</td>
            <td> </td>

            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
        </table>
      </div>
       
        
      <div class = "margin3-cointainer">
      <div class=" new">
          <label for="one" class="heading-3">
            {" "}
            <b>
              {" "}
              1.2.3: Average percentage of student enrolled in Certificate/Add-on programs as aganist the total number of student during the last five years
            </b>{" "}
          </label>
          <input id="one" class="size" type=" text" />{" "}
        </div>
        <hr></hr>
        <div class="adjustment-7">
          <label for="one">
            <b>
             1.2.3.1:Number of student enrolled in value
             added  course(beyond the curricum) offered years.wise during last five years{" "}
            </b>{" "}
          </label>
          <table class="table2">
            <tr>
              <th>2018-19</th>
              <th>2017-18</th>
              <th>2016-17</th>
              <th>2015-16</th>
              <th>2014-15</th>
            </tr>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
            <td>
              <input />
            </td>
          </table>
        </div>
        <hr></hr>
        <div class="adjustment-8">
          
            <b>Related Input</b>
            <p> <br></br>Number of students offered year wise for last fiver year?
          </p>
          <table class="table-2" border="1px" solid black>
            <tr>
              <th>Year1</th>
              <th>Year2</th>
              <th>Year3</th>
              <th>Year4</th>
              <th>Year5</th>
            </tr>
            <td>1008</td>
            <td>1337</td>
            <td>1694</td>
            <td>1893</td>
            <td>1697</td>
          </table>
         <hr></hr>
         <p>Total academic year considered: 5</p>
        </div>
        <hr></hr>
        <hr></hr>
        <table class="adjustment-9">
          <tr class="color-1">
            <th> File Description</th>
            <th> Template </th>
            <th> Documents </th>
          </tr>
          <tr>
            <td>
              Details of the studnets enrolled in subjects related to certificates/Add on programs {" "}
              <span class="red-star">★</span>
            </td>
            <td>
              <a href="url">Data Template </a>
            </td>

            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>
          <tr>
            <td>
             Any additional information
            </td>
            <td></td>
            <td>
              <button class="btn help">Upload</button>&nbsp;
              <span>&#63;</span>
            </td>
          </tr>

          
        </table>
      </div>
      </div>
  
  );
};

export default C2;
